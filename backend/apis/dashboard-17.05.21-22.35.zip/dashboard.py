from backend import app
from backend.model.client import Client, Broker

from flask import render_template, request

import paho.mqtt.client as mqtt
import json


@app.route('/dashboard', methods=['GET'])
def dashboard_index():
    clients = Client.query.all()
    return render_template('group.html', clients=clients)


@app.route('/send_message', methods=['POST'])
def send_message():
    data = request.get_json()

    brokers = dict()
    for client in data['clients']:
        if client['broker_id'] not in brokers:
            brokers[client['broker_id']] = list()
        brokers[client['broker_id']].append(client['client_id'])

    client = mqtt.Client()
    client.connect('127.0.0.1', 1883)

    for b, c in brokers.items():
        msg = dict()
        msg['topic'] = data['topic']
        msg['msg'] = data['msg']
        msg['clients'] = c
        client.publish(b, json.dumps(msg))
    client.disconnect()
    print(brokers)
    return 'done'
